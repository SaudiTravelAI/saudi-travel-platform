# API Design Document
## Saudi Travel Platform — REST API v1
**Version:** 1.0.0  
**Base URL:** `https://api.saudtraveltech.com/api/v1`  
**Format:** JSON  
**Auth:** Bearer JWT

---

## API Design Principles

1. **Versioning:** URL-based versioning (`/api/v1/`, `/api/v2/`)
2. **Naming:** Plural nouns for resources (`/flights`, `/hotels`, `/bookings`)
3. **HTTP Methods:** GET (read), POST (create), PUT (replace), PATCH (update), DELETE (remove)
4. **Status Codes:** Standard HTTP codes used consistently
5. **Pagination:** Cursor-based for large datasets, offset for admin panels
6. **Filtering:** Query parameters on GET requests
7. **Language:** Accept-Language header (`ar`, `en`)
8. **Currency:** X-Currency header for price formatting
9. **Error Format:** Consistent error response structure
10. **Rate Limiting:** Headers: X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset

---

## Standard Response Envelopes

### Success Response
```json
{
  "success": true,
  "data": { ... },
  "meta": {
    "pagination": {
      "current_page": 1,
      "per_page": 20,
      "total": 156,
      "last_page": 8,
      "next_cursor": "eyJpZCI6MTIzfQ=="
    }
  },
  "message": null
}
```

### Error Response
```json
{
  "success": false,
  "error": {
    "code": "BOOKING_EXPIRED",
    "message": "Your session has expired. Please search again.",
    "message_ar": "انتهت صلاحية الجلسة. يرجى البحث مجددًا.",
    "details": {}
  }
}
```

### Validation Error Response (422)
```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The given data was invalid.",
    "details": {
      "email": ["The email field is required."],
      "departure_date": ["The departure date must be in the future."]
    }
  }
}
```

---

## 1. Authentication Endpoints

### POST /auth/register
Register a new customer account.
```json
// Request
{
  "first_name": "Ahmed",
  "last_name": "Al-Rashidi",
  "email": "ahmed@example.com",
  "phone": "+966501234567",
  "password": "SecurePass123!",
  "password_confirmation": "SecurePass123!",
  "language": "ar",
  "agree_terms": true
}

// Response 201
{
  "success": true,
  "data": {
    "user": { "id": "uuid", "email": "ahmed@example.com", ... },
    "tokens": {
      "access_token": "eyJ...",
      "refresh_token": "eyJ...",
      "expires_in": 900
    }
  }
}
```

### POST /auth/login
```json
// Request
{ "email": "ahmed@example.com", "password": "SecurePass123!", "device_id": "uuid" }

// Response 200
{
  "success": true,
  "data": {
    "user": { ... },
    "tokens": { "access_token": "eyJ...", "refresh_token": "eyJ...", "expires_in": 900 }
  }
}
```

### POST /auth/refresh
Exchange refresh token for new access token.

### POST /auth/logout
Revoke current refresh token.

### POST /auth/password/forgot
Send password reset email.

### POST /auth/password/reset
Reset password with token.

### POST /auth/verify/email
Verify email with OTP.

### POST /auth/verify/phone
Verify phone with OTP.

### POST /auth/social/google
OAuth2 login with Google.

### POST /auth/social/apple
Sign in with Apple.

---

## 2. User Profile Endpoints

### GET /profile
Get authenticated user profile.

### PATCH /profile
Update profile fields.

### GET /profile/documents
Get saved travel documents.

### POST /profile/documents
Save passport / national ID.

### GET /profile/passengers
Get saved passenger profiles.

### POST /profile/passengers
Save a passenger profile.

### PATCH /profile/passengers/{id}
Update passenger profile.

### DELETE /profile/passengers/{id}
Remove saved passenger.

---

## 3. Flight Search & Booking

### POST /flights/search
Search for available flights.
```json
// Request
{
  "trip_type": "round",          // one_way | round | multi_city
  "origin": "RUH",
  "destination": "DXB",
  "departure_date": "2025-03-15",
  "return_date": "2025-03-22",
  "cabin_class": "economy",      // economy | business | first
  "adults": 2,
  "children": 1,
  "infants": 0,
  "currency": "SAR",
  "preferred_airlines": ["SV", "EK"],  // optional
  "max_stops": 1,
  "sort_by": "price"             // price | duration | departure
}

// Response 200
{
  "success": true,
  "data": {
    "search_id": "uuid",         // Used for booking
    "expires_at": "2025-...",
    "results": [
      {
        "result_id": "uuid",
        "supplier": "duffel",
        "flights": [
          {
            "flight_number": "SV456",
            "airline": { "iata": "SV", "name": "Saudia", "logo": "..." },
            "origin": { "iata": "RUH", "name": "King Khalid International Airport" },
            "destination": { "iata": "DXB", "name": "Dubai International Airport" },
            "departure_at": "2025-03-15T08:00:00+03:00",
            "arrival_at": "2025-03-15T10:30:00+04:00",
            "duration_minutes": 90,
            "stops": 0,
            "cabin_class": "economy",
            "available_seats": 9
          }
        ],
        "pricing": {
          "currency": "SAR",
          "base_fare": 850.00,
          "taxes": 127.50,
          "fees": 0,
          "total": 977.50,
          "per_person": 488.75,
          "breakdown": { ... }
        },
        "baggage": { "carry_on": "7kg", "checked": "23kg" },
        "fare_conditions": ["non_refundable", "no_date_change"],
        "ai_score": 92          // AI recommendation score
      }
    ],
    "filters": {
      "airlines": [...],
      "stops": [...],
      "price_range": { "min": 450, "max": 2800 },
      "departure_times": [...]
    },
    "ai_recommendation": {
      "best_value": "uuid",
      "cheapest": "uuid",
      "fastest": "uuid"
    }
  }
}
```

### GET /flights/search/{search_id}
Retrieve cached search results.

### POST /flights/search/{search_id}/revalidate
Revalidate pricing before booking.

### POST /flights/book
Create a flight booking.
```json
// Request
{
  "search_id": "uuid",
  "result_id": "uuid",
  "passengers": [
    {
      "type": "adult",
      "title": "Mr",
      "first_name": "Ahmed",
      "last_name": "Al-Rashidi",
      "date_of_birth": "1990-05-15",
      "gender": "male",
      "nationality": "SA",
      "passport_number": "A12345678",
      "passport_expiry": "2028-01-01",
      "passport_country": "SA",
      "frequent_flyer": [{ "airline": "SV", "number": "12345" }]
    }
  ],
  "contact": {
    "email": "ahmed@example.com",
    "phone": "+966501234567"
  },
  "seat_selections": [],          // Optional
  "ancillaries": [],              // Optional: extra baggage, meals
  "payment": {
    "method": "card",
    "gateway": "hyperpay",
    "currency": "SAR"
  },
  "coupon_code": "SUMMER25",     // Optional
  "use_wallet": false             // Optional
}

// Response 201
{
  "success": true,
  "data": {
    "booking_id": "uuid",
    "reference": "STT-2025-000123",
    "status": "payment_pending",
    "payment_url": "https://hyperpay.com/checkout/...",   // Redirect URL
    "total": 1955.00,
    "currency": "SAR"
  }
}
```

### GET /flights/bookings/{reference}
Get flight booking details.

### POST /flights/bookings/{reference}/cancel
Cancel a flight booking.

### GET /flights/bookings/{reference}/checkin
Get check-in information and link.

---

## 4. Hotel Search & Booking

### POST /hotels/search
```json
// Request
{
  "destination": "Dubai",        // City name or city_id
  "check_in": "2025-03-15",
  "check_out": "2025-03-20",
  "rooms": [
    { "adults": 2, "children": [8] }   // Children ages
  ],
  "currency": "SAR",
  "filters": {
    "star_rating": [4, 5],
    "max_price": 1500,
    "amenities": ["pool", "wifi", "gym"],
    "board_type": ["bb", "fb"]
  },
  "sort_by": "price",
  "coordinates": {               // Optional: search around location
    "lat": 25.2048,
    "lng": 55.2708,
    "radius_km": 5
  }
}

// Response 200
{
  "success": true,
  "data": {
    "search_id": "uuid",
    "total_results": 142,
    "results": [
      {
        "hotel": {
          "id": "uuid",
          "name": "Burj Al Arab",
          "name_ar": "برج العرب",
          "star_rating": 5,
          "address": "Jumeirah Beach Road, Dubai",
          "coordinates": { "lat": 25.141, "lng": 55.185 },
          "images": ["..."],
          "rating": { "score": 9.2, "label": "Exceptional", "reviews_count": 2847 },
          "amenities": ["pool", "spa", "gym", "restaurant", "wifi"]
        },
        "rooms": [
          {
            "room_id": "uuid",
            "result_id": "uuid",
            "name": "Deluxe Sea View Room",
            "board_type": "BB",
            "max_occupancy": 2,
            "images": ["..."],
            "pricing": {
              "currency": "SAR",
              "per_night": 1850.00,
              "total": 9250.00,
              "taxes_included": true
            },
            "cancellation_policy": {
              "type": "free_cancellation",
              "free_until": "2025-03-12T00:00:00Z"
            },
            "supplier": "ratehawk"
          }
        ],
        "ai_score": 88
      }
    ]
  }
}
```

### GET /hotels/{id}
Get hotel details with static content.

### POST /hotels/book
Create hotel booking.

### GET /hotels/bookings/{reference}
Get hotel booking details.

### POST /hotels/bookings/{reference}/cancel
Cancel hotel booking.

---

## 5. Packages

### GET /packages
List featured and pre-configured packages.

### GET /packages/{id}
Get package details.

### POST /packages/search
Search dynamic packages (flight + hotel).

### POST /packages/book
Book a package.

---

## 6. Bookings Management

### GET /bookings
List user's bookings (all types).
```
Query: status, type, from_date, to_date, page, per_page
```

### GET /bookings/{reference}
Get full booking details with all sub-items.

### POST /bookings/{reference}/cancel
Request booking cancellation.

### POST /bookings/{reference}/refund
Request refund after cancellation.

### GET /bookings/{reference}/invoice
Download invoice PDF.

### GET /bookings/{reference}/voucher
Download booking voucher PDF.

---

## 7. Payments

### POST /payments/initiate
Initiate payment for a booking.

### POST /payments/callback
Payment gateway webhook (public, signature-verified).

### GET /payments/status/{payment_id}
Check payment status.

### GET /wallet
Get user wallet balance and summary.

### POST /wallet/topup
Top up wallet.

### GET /wallet/transactions
Get wallet transaction history.

---

## 8. Coupons & Gift Cards

### POST /coupons/validate
Validate a coupon code.
```json
// Request
{ "code": "SUMMER25", "booking_type": "flight", "amount": 977.50 }

// Response
{
  "success": true,
  "data": {
    "coupon_id": "uuid",
    "discount_type": "percentage",
    "discount_value": 25,
    "discount_amount": 244.38,
    "final_amount": 733.12
  }
}
```

### POST /gift-cards/validate
Validate a gift card.

### POST /gift-cards/purchase
Purchase a gift card.

---

## 9. AI Features

### POST /ai/trip-planner
Generate AI trip itinerary.
```json
// Request
{
  "destination": "Istanbul",
  "duration_days": 7,
  "travelers": 2,
  "interests": ["history", "food", "shopping"],
  "budget": "moderate",
  "departure_city": "Riyadh",
  "travel_dates": "2025-04-10"
}

// Response (streamed)
{
  "success": true,
  "data": {
    "itinerary": {
      "title": "7 Days in Istanbul",
      "overview": "...",
      "days": [
        {
          "day": 1,
          "title": "Arrival & Old City",
          "activities": [...]
        }
      ],
      "estimated_budget": { "min": 5000, "max": 8000, "currency": "SAR" },
      "flight_suggestions": [...],
      "hotel_suggestions": [...]
    }
  }
}
```

### POST /ai/search
Natural language search.
```json
// Request
{ "query": "رحلة عائلية إلى تركيا الشهر القادم لأربعة أفراد" }

// Response
{
  "success": true,
  "data": {
    "interpreted": {
      "destination": "Turkey",
      "travelers": { "adults": 2, "children": 2 },
      "month": "March 2025"
    },
    "results": { ... }
  }
}
```

### POST /ai/chat
AI assistant conversation.
```json
// Request
{
  "message": "What are the visa requirements for Saudi citizens traveling to Japan?",
  "conversation_id": "uuid",   // Null for new conversation
  "language": "en"
}
```

### GET /ai/recommendations/flights
Personalized flight recommendations.

### GET /ai/recommendations/hotels
Personalized hotel recommendations.

### GET /ai/price-prediction
Price prediction for a route.
```
Query: origin=RUH&destination=DXB&departure_date=2025-06-15&cabin_class=economy
```

---

## 10. Notifications

### GET /notifications
List user notifications.

### PATCH /notifications/{id}/read
Mark notification as read.

### POST /notifications/read-all
Mark all notifications as read.

### GET /notifications/preferences
Get notification preferences.

### PATCH /notifications/preferences
Update notification preferences.

---

## 11. Reviews

### GET /reviews
List reviews (by hotel, airline, etc).

### POST /reviews
Create a review.

### PUT /reviews/{id}
Update a review.

### DELETE /reviews/{id}
Delete a review.

---

## 12. Support

### GET /support/tickets
List support tickets.

### POST /support/tickets
Create a support ticket.

### GET /support/tickets/{id}
Get ticket details and messages.

### POST /support/tickets/{id}/messages
Reply to a support ticket.

### POST /support/tickets/{id}/close
Close a ticket.

---

## 13. Favorites

### GET /favorites
List user's favorites.

### POST /favorites
Add to favorites.

### DELETE /favorites/{id}
Remove from favorites.

---

## 14. Admin Endpoints (Protected: Admin Roles Only)

### Users Management
- `GET /admin/users` — List all users with filters
- `GET /admin/users/{id}` — User details
- `PATCH /admin/users/{id}` — Update user
- `POST /admin/users/{id}/suspend` — Suspend account
- `POST /admin/users/{id}/verify` — Manually verify

### Bookings Management
- `GET /admin/bookings` — All bookings with filters
- `GET /admin/bookings/{reference}` — Full booking details
- `POST /admin/bookings/{reference}/cancel` — Force cancel
- `POST /admin/bookings/{reference}/refund` — Process refund

### Suppliers Management
- `GET /admin/suppliers` — List suppliers
- `POST /admin/suppliers` — Add supplier
- `PATCH /admin/suppliers/{id}` — Update supplier config
- `GET /admin/suppliers/{id}/logs` — API logs

### Analytics & Reports
- `GET /admin/analytics/revenue` — Revenue reports
- `GET /admin/analytics/bookings` — Booking statistics
- `GET /admin/analytics/users` — User growth metrics
- `GET /admin/reports/export` — Export CSV/Excel

---

## Error Codes Reference

| Code | HTTP | Description |
|------|------|-------------|
| UNAUTHENTICATED | 401 | No or invalid token |
| UNAUTHORIZED | 403 | Insufficient permissions |
| NOT_FOUND | 404 | Resource not found |
| VALIDATION_ERROR | 422 | Input validation failed |
| SEARCH_EXPIRED | 410 | Search session expired |
| PRICE_CHANGED | 409 | Price changed since search |
| NO_AVAILABILITY | 409 | No seats/rooms available |
| PAYMENT_FAILED | 402 | Payment gateway declined |
| SUPPLIER_ERROR | 502 | Upstream supplier API error |
| RATE_LIMITED | 429 | Too many requests |
| BOOKING_NOT_CANCELLABLE | 422 | Outside cancellation window |

---

## API Rate Limits

| Endpoint Group | Limit |
|---------------|-------|
| Authentication | 10 req/min per IP |
| Flight Search | 30 req/min per user |
| Hotel Search | 30 req/min per user |
| Booking | 5 req/min per user |
| AI Endpoints | 20 req/min per user |
| General | 120 req/min per user |
| Admin | 300 req/min per admin |
