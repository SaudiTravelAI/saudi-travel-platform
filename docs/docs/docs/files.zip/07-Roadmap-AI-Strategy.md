# Development Roadmap & AI Integration Strategy
## Saudi Travel Platform
**Version:** 1.0.0

---

## Development Roadmap

### PHASE 1 — Foundation (Weeks 1–6)
**Goal:** Infrastructure + Authentication + Core Framework

#### Week 1–2: Infrastructure
- [ ] Set up GCP project and IAM roles
- [ ] Configure Cloud Run, Cloud SQL, Memorystore
- [ ] Set up Secret Manager for all credentials
- [ ] Configure Cloud Build CI/CD pipelines
- [ ] Set up environments: dev, staging, production
- [ ] Configure Cloud Monitoring and alerting
- [ ] Docker containerization for Laravel app
- [ ] Set up Artifact Registry for container images

#### Week 3–4: Backend Foundation
- [ ] Initialize Laravel 12 project with PHP 8.4
- [ ] Configure PostgreSQL with migrations framework
- [ ] Implement JWT authentication system
- [ ] Build user registration and login
- [ ] Implement RBAC (roles & permissions)
- [ ] Set up Redis queue with Laravel Horizon
- [ ] Configure email (Postmark) and SMS (Unifonic)
- [ ] Write base test infrastructure (PHPUnit + Feature tests)

#### Week 5–6: Flutter Foundation
- [ ] Initialize Flutter project with clean architecture
- [ ] Configure GoRouter navigation
- [ ] Implement Riverpod state management setup
- [ ] Build reusable component library
- [ ] Configure localization (Arabic + English, RTL)
- [ ] Implement dark mode support
- [ ] Set up Firebase (Auth, FCM, Analytics, Crashlytics)
- [ ] Build authentication screens (Login, Register, OTP)

**Exit Criteria:** Users can register, log in, and receive a JWT. CI/CD deploys to staging automatically.

---

### PHASE 2 — Core Travel Products (Weeks 7–14)
**Goal:** Flight and Hotel booking end-to-end

#### Week 7–8: Supplier Integration Layer
- [ ] Build FlightSupplierInterface abstraction
- [ ] Integrate Duffel API (primary flight supplier)
- [ ] Integrate RateHawk API (primary hotel supplier)
- [ ] Build result aggregation and normalization
- [ ] Implement supplier result caching in Redis
- [ ] Build API logs with request/response storage
- [ ] Error handling and supplier failover logic

#### Week 9–10: Flight Booking
- [ ] Flight search API with multi-supplier aggregation
- [ ] Price revalidation before booking
- [ ] Passenger data collection and validation
- [ ] Flight booking creation and PNR issuance
- [ ] E-ticket generation and email delivery
- [ ] Flight booking management (retrieve, cancel)
- [ ] Flutter: Flight search, results, detail, booking screens

#### Week 11–12: Hotel Booking
- [ ] Hotel search API
- [ ] Hotel static content management (sync from supplier)
- [ ] Room availability and pricing
- [ ] Hotel booking creation
- [ ] Voucher generation and email delivery
- [ ] Flutter: Hotel search, results, detail, booking screens

#### Week 13–14: Payments
- [ ] HyperPay integration (card, Apple Pay, STC Pay)
- [ ] Moyasar integration (backup gateway)
- [ ] Payment status webhooks
- [ ] Wallet top-up and deduction
- [ ] Coupon validation and application
- [ ] ZATCA-compliant invoice generation
- [ ] Flutter: Payment screens, wallet screen

**Exit Criteria:** End-to-end flight and hotel booking works in production with real supplier APIs.

---

### PHASE 3 — Extended Products (Weeks 15–20)
**Goal:** Full product catalog

#### Week 15–16: Additional Products
- [ ] Car rental integration (TBO or RateHawk cars)
- [ ] Airport transfer integration
- [ ] Activity and tours module
- [ ] Visa services module (manual/partner assisted)
- [ ] Travel insurance module

#### Week 17–18: Customer Experience
- [ ] Push notification system (FCM)
- [ ] In-app notification center
- [ ] Email notification templates (AR + EN)
- [ ] Flight status updates (via airline API or FlightAware)
- [ ] Review and rating system
- [ ] Favorites / saved items
- [ ] Customer support ticket system

#### Week 19–20: Gift Cards & Loyalty
- [ ] Gift card issuance and redemption
- [ ] Points/loyalty program (if in scope)
- [ ] Referral program
- [ ] Flutter: All new product screens + support screens

**Exit Criteria:** All travel products bookable. Customers can communicate with support.

---

### PHASE 4 — AI Integration (Weeks 21–24)
**Goal:** AI-powered features

#### Week 21–22: Core AI Services
- [ ] Integrate Anthropic Claude API
- [ ] Build AI Chat Assistant (24/7 support)
- [ ] Build AI Trip Planner with itinerary generation
- [ ] Implement Natural Language Search interpretation
- [ ] AI-powered FAQ answering

#### Week 23–24: AI Intelligence
- [ ] Build personalized recommendation engine
- [ ] Implement price prediction model (historical data)
- [ ] AI-generated push notification content
- [ ] AI-generated marketing content for CMS
- [ ] AI smart upselling suggestions during booking
- [ ] Flutter: AI chat screen, trip planner screen

**Exit Criteria:** AI features live and A/B tested against baseline conversion rates.

---

### PHASE 5 — B2B & Corporate (Weeks 25–30)
**Goal:** Revenue channels beyond B2C

#### Week 25–26: Travel Agent Portal
- [ ] Agent registration and onboarding
- [ ] B2B pricing with agent markups
- [ ] Agent booking on behalf of customers
- [ ] Agent commission tracking
- [ ] Agent dashboard and reports
- [ ] Sub-agent management

#### Week 27–28: Corporate Portal
- [ ] Corporate account registration
- [ ] Employee management
- [ ] Travel policy configuration
- [ ] Multi-level booking approval workflow
- [ ] Consolidated corporate invoicing
- [ ] Cost center reporting
- [ ] Credit limit management

#### Week 29–30: Affiliate & API Program
- [ ] Affiliate tracking links
- [ ] Commission calculation and payout
- [ ] White-label API for third parties
- [ ] API key management and rate limiting
- [ ] Affiliate dashboard

**Exit Criteria:** At least 3 travel agents and 1 corporate account live.

---

### PHASE 6 — Launch Preparation (Weeks 31–34)
**Goal:** Production-ready

- [ ] Performance testing (load test to 1,000 concurrent users)
- [ ] Security penetration testing by external firm
- [ ] OWASP vulnerability scanning
- [ ] PDPL compliance review
- [ ] App Store submission (iOS)
- [ ] Google Play submission (Android)
- [ ] CMS content population (AR + EN)
- [ ] Supplier commercial agreements finalized
- [ ] Payment gateway compliance (PCI DSS review)
- [ ] Soft launch with invited beta users (500 users)
- [ ] Monitoring dashboards and runbooks
- [ ] On-call rotation and incident response procedures

---

## AI Integration Strategy

### Architecture
All AI features route through a centralized `AI Module` in Laravel that:
1. Maintains conversation context
2. Enforces rate limits
3. Logs all AI interactions for quality review
4. Handles fallback when AI is unavailable

```
User Request → AI Module → Claude API (claude-sonnet-4-6)
                        → Context Enrichment (user data, booking history)
                        → Response Post-processing
                        → Structured Output Parsing
```

### Feature Details

#### 1. AI Chat Assistant
- **Model:** claude-sonnet-4-6
- **Context:** User profile, booking history, current page context
- **Capabilities:** Booking help, travel advice, FAQ answering, complaint handling
- **Escalation:** Auto-escalate to human agent after 3 failed resolution attempts
- **Languages:** Arabic and English with automatic detection

#### 2. AI Trip Planner
- **Input:** Destination, dates, budget, interests, party composition
- **Output:** Day-by-day itinerary with flight and hotel suggestions
- **Integration:** Suggestions link directly to search results
- **Streaming:** Response streams to improve perceived performance

#### 3. AI Smart Search
- **Input:** Natural language query in Arabic or English
- **Output:** Structured search parameters
- **Example:** "رحلة لإسطنبول في رمضان لعائلة مكونة من 4 أفراد" →
  ```json
  { "destination": "IST", "month": "March", "adults": 2, "children": 2 }
  ```

#### 4. Price Prediction
- **Data:** Historical pricing stored in analytics database
- **Model:** Claude analyzes trends + statistical model (ARIMA/Prophet)
- **Output:** Price direction (up/down/stable) + confidence % + best booking window
- **Display:** "Prices are likely to increase in the next 7 days" with chart

#### 5. Recommendation Engine
- **Signals:** Search history, booking history, favorites, similar users
- **Output:** Personalized destination cards and deal highlights
- **A/B Testing:** Compare AI recommendations vs editorial picks

#### 6. AI Marketing Generator
- **Admin tool:** Generate email, push, and SMS campaign content
- **Input:** Target segment, promotion type, budget range
- **Output:** AR + EN content ready for review and publish

### Claude API Integration Code Pattern

```php
// app/Core/AI/ClaudeService.php

final class ClaudeService
{
    private const MODEL = 'claude-sonnet-4-6';
    private const MAX_TOKENS = 4096;

    public function __construct(
        private readonly string $apiKey,
        private readonly ApiLogRepository $logs,
    ) {}

    public function complete(
        string $systemPrompt,
        array $messages,
        bool $stream = false,
        int $maxTokens = self::MAX_TOKENS,
    ): string {
        $startTime = microtime(true);

        $response = Http::withHeaders([
            'x-api-key' => $this->apiKey,
            'anthropic-version' => '2023-06-01',
        ])->post('https://api.anthropic.com/v1/messages', [
            'model'      => self::MODEL,
            'max_tokens' => $maxTokens,
            'system'     => $systemPrompt,
            'messages'   => $messages,
        ]);

        $duration = (int) ((microtime(true) - $startTime) * 1000);

        $this->logs->create([
            'supplier' => 'anthropic',
            'duration_ms' => $duration,
            'status_code' => $response->status(),
        ]);

        if ($response->failed()) {
            throw new AIServiceException('Claude API error: ' . $response->body());
        }

        return $response->json('content.0.text');
    }
}
```

---

## Google Cloud Architecture Diagram

```
Internet Users
      │
      ▼
Cloud Armor (WAF + DDoS Protection)
      │
      ▼
Global Load Balancer (SSL Termination)
      │
      ├──────────────────────────────────┐
      │                                  │
      ▼                                  ▼
Cloud CDN                          Cloud Run
(Static Assets:                    (Laravel API)
 Flutter Web, Images)               │    │
                                    │    │
                               Cloud SQL  Memorystore
                               (PostgreSQL) (Redis)
                                    │
                               Cloud Storage
                               (GCS: Files,
                                Backups, Media)

Separate Cloud Run Services:
- API (main)
- Queue Worker (Laravel Horizon)
- Scheduler (Laravel Schedule)

Firebase Services:
- Authentication
- FCM (Push Notifications)
- Analytics
- Crashlytics

External APIs:
- Anthropic Claude (AI)
- Google Maps Platform
- Duffel / Amadeus / Sabre (Flights)
- RateHawk / Hotelbeds (Hotels)
- HyperPay / Moyasar (Payments)
- Postmark (Email)
- Unifonic (SMS)
```

---

## Security Checklist (Pre-Launch)

### Authentication
- [ ] JWT secret rotation mechanism in place
- [ ] Refresh token single-use enforcement
- [ ] Account lockout after 5 failed login attempts
- [ ] MFA available for all users
- [ ] Admin accounts require MFA

### API Security
- [ ] Rate limiting on all endpoints
- [ ] Input validation on all request fields
- [ ] SQL injection protection (Eloquent ORM)
- [ ] XSS protection headers configured
- [ ] CORS configured correctly
- [ ] API keys never exposed in responses

### Data Security
- [ ] Passport numbers encrypted at rest
- [ ] Card numbers never stored (tokenized by gateway)
- [ ] PII fields logged minimally
- [ ] PDPL data retention policies implemented
- [ ] Audit log for all sensitive operations

### Infrastructure
- [ ] Cloud SQL private IP only (no public access)
- [ ] Redis password-protected
- [ ] GCS buckets not publicly listable
- [ ] Secret Manager for all credentials
- [ ] Cloud Armor rules active
- [ ] Vulnerability scanning in CI/CD pipeline
