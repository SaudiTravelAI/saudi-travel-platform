# System Architecture Document
## Saudi Travel Platform
**Version:** 1.0.0

---

## 1. Architecture Overview

The Saudi Travel Platform follows a **Layered Microservice-Ready Architecture** built on Laravel 12, designed for cloud-native deployment on Google Cloud Platform. While the initial deployment uses a modular monolith pattern for speed-to-market, each module is independently deployable and can be extracted into a standalone microservice without business logic changes.

### Core Principles
- **API First:** Every feature is accessible via REST API before any UI is built
- **Supplier Agnostic:** All travel suppliers connect through a common adapter interface
- **Event Driven:** Business events are published to queues for async processing
- **Stateless Services:** No session state stored in application servers
- **Defense in Depth:** Security applied at network, application, and data layers

---

## 2. Architecture Layers

```
┌─────────────────────────────────────────────────────┐
│              Client Applications                     │
│   Flutter (iOS · Android · Web) │ Admin · B2B       │
└─────────────────┬───────────────────────────────────┘
                  │ HTTPS / TLS 1.3
┌─────────────────▼───────────────────────────────────┐
│           Cloud Load Balancer + Cloud CDN            │
└─────────────────┬───────────────────────────────────┘
                  │
┌─────────────────▼───────────────────────────────────┐
│              API Gateway (Cloud Run)                 │
│   Rate Limit · Auth Validation · Request Routing    │
└────────┬────────────────────────┬───────────────────┘
         │                        │
┌────────▼─────────┐   ┌──────────▼─────────────────┐
│  Laravel API     │   │  Static Assets              │
│  (Cloud Run)     │   │  (Cloud CDN + GCS)          │
│  - Modules       │   └────────────────────────────┘
│  - Services      │
│  - Jobs/Events   │
└────┬──────┬──────┘
     │      │
  ┌──▼──┐ ┌─▼──────────────────┐
  │ SQL │ │ Redis (Memorystore) │
  │ PG  │ │ Cache · Queue · Pub│
  └─────┘ └────────────────────┘
     │
  ┌──▼──────────────────────────┐
  │   Supplier Integration Layer │
  │   Flight · Hotel · Package   │
  │   Payment · AI · Maps        │
  └────────────────────────────┘
```

---

## 3. Backend Module Architecture

### 3.1 Module Structure (Domain-Driven)
Each domain module in Laravel follows the same internal structure:

```
app/
├── Modules/
│   ├── Auth/
│   │   ├── Controllers/
│   │   ├── Services/
│   │   ├── Repositories/
│   │   ├── Models/
│   │   ├── DTOs/
│   │   ├── Events/
│   │   ├── Listeners/
│   │   ├── Jobs/
│   │   ├── Requests/
│   │   ├── Resources/
│   │   └── Routes/
│   ├── Flights/
│   ├── Hotels/
│   ├── Bookings/
│   ├── Payments/
│   ├── Wallet/
│   ├── Packages/
│   ├── Transfers/
│   ├── Cars/
│   ├── Activities/
│   ├── Visa/
│   ├── Insurance/
│   ├── Notifications/
│   ├── Support/
│   ├── Reviews/
│   ├── Analytics/
│   ├── CMS/
│   └── Admin/
├── Core/
│   ├── Contracts/          # Interfaces and abstractions
│   ├── Suppliers/          # Supplier adapter layer
│   │   ├── Contracts/
│   │   ├── Flights/
│   │   └── Hotels/
│   ├── Payments/           # Payment gateway adapters
│   ├── AI/                 # AI service integrations
│   └── Http/               # Global middleware
```

### 3.2 Repository Pattern
All data access is abstracted through repositories:
```php
interface FlightRepositoryInterface {
    public function search(FlightSearchDTO $dto): FlightResultCollection;
    public function findByPNR(string $pnr): ?Flight;
    public function createBooking(FlightBookingDTO $dto): FlightBooking;
}
```

### 3.3 Supplier Adapter Pattern
New suppliers can be added without modifying existing code:
```php
interface FlightSupplierInterface {
    public function search(FlightSearchDTO $dto): SupplierResultCollection;
    public function book(FlightBookingDTO $dto): SupplierBookingResult;
    public function cancel(string $bookingRef): CancellationResult;
    public function retrieve(string $pnr): PNRDetails;
}

class DuffelAdapter implements FlightSupplierInterface { ... }
class AmadeusAdapter implements FlightSupplierInterface { ... }
class SabreAdapter implements FlightSupplierInterface { ... }
```

---

## 4. Google Cloud Architecture

### 4.1 GCP Services Used
| Service | Purpose |
|---------|---------|
| Cloud Run | Serverless backend containers (auto-scaling) |
| Cloud SQL | Managed PostgreSQL with HA |
| Memorystore | Managed Redis for cache and queues |
| Cloud Storage (GCS) | File storage, backups, static assets |
| Cloud CDN | Global content delivery |
| Cloud Load Balancing | Traffic distribution and SSL termination |
| Secret Manager | Secure secrets and API keys storage |
| Cloud Monitoring | Metrics, alerting, uptime checks |
| Cloud Logging | Centralized log aggregation |
| Cloud Armor | DDoS protection and WAF |
| Artifact Registry | Docker image registry |
| Cloud Build | CI/CD pipeline |
| Firebase | Auth, FCM push, Analytics, Crashlytics |
| Google Maps Platform | Maps, Places, Directions |

### 4.2 Network Architecture
```
Internet → Cloud Armor (WAF/DDoS) → Cloud Load Balancer
→ Cloud CDN → Cloud Run (Backend)
→ Cloud SQL Private IP
→ Memorystore Private IP
→ GCS (via VPC-SC)
```

### 4.3 Region Strategy
- Primary: `me-central1` (Dammam, Saudi Arabia) — data residency compliance
- Failover: `me-west1` (Tel Aviv) or `europe-west1` (Belgium)

---

## 5. Security Architecture

### 5.1 Authentication Flow
```
Client → POST /api/v1/auth/login
       → Validate credentials
       → Issue JWT (15min) + Refresh Token (30days, stored in Redis)
       → Client stores tokens securely (Flutter Secure Storage)
       → Subsequent requests: Authorization: Bearer {jwt}
       → Auto-refresh via interceptor before expiry
```

### 5.2 Authorization Layers
1. **Network Layer:** Cloud Armor rules, rate limiting
2. **Gateway Layer:** JWT validation, IP allowlist for B2B
3. **Application Layer:** RBAC middleware on every route
4. **Data Layer:** Row-level security for multi-tenant data

### 5.3 Data Encryption
- **In Transit:** TLS 1.3 for all communications
- **At Rest:** AES-256 via Cloud SQL encryption, GCS CMEK
- **Application Level:** Sensitive fields (passport numbers, card tokens) encrypted with AES-256-CBC before storage

---

## 6. Scalability Strategy

### 6.1 Horizontal Scaling
- Cloud Run auto-scales from 0 to N instances based on CPU/request metrics
- Min instances: 2 (to avoid cold starts in production)
- Max instances: 100 (configurable per environment)

### 6.2 Database Scaling
- Read replicas for search and reporting queries
- Connection pooling via PgBouncer
- Caching layer: Redis for frequently accessed data (exchange rates, airline data, hotel static content)

### 6.3 Queue Architecture
- Laravel Horizon running on dedicated Cloud Run service
- Separate queues: `default`, `bookings`, `notifications`, `emails`, `ai-processing`
- Dead-letter queue for failed jobs with alerting

---

## 7. Development Phases

### Phase 1 — Foundation (Weeks 1–6)
- Infrastructure setup (GCP, CI/CD, environments)
- Core authentication and user management
- Database schema design and migrations
- Base API framework and documentation

### Phase 2 — Core Travel (Weeks 7–14)
- Flight search and booking (2 suppliers minimum)
- Hotel search and booking (2 suppliers minimum)
- Payment integration (HyperPay + Moyasar)
- Basic booking management

### Phase 3 — Extended Products (Weeks 15–20)
- Car rental, transfers, activities
- Visa and insurance modules
- Wallet and coupons
- Reviews and favorites

### Phase 4 — AI & Intelligence (Weeks 21–24)
- AI Trip Planner
- Smart search
- Price prediction
- Recommendation engine

### Phase 5 — B2B & Corporate (Weeks 25–30)
- Travel agents portal
- Corporate portal with policy management
- Affiliate program
- Advanced reporting

### Phase 6 — Launch Preparation (Weeks 31–34)
- Performance testing and optimization
- Security penetration testing
- App Store and Google Play submission
- Soft launch and monitoring
