# Laravel Project Structure
## Saudi Travel Platform — Backend
**Stack:** Laravel 12 · PHP 8.4 · PostgreSQL · Redis

---

## Folder Structure

```
saudi-travel-api/
│
├── app/
│   ├── Core/                           # Shared infrastructure (no business logic)
│   │   ├── Contracts/
│   │   │   ├── SupplierInterface.php
│   │   │   ├── PaymentGatewayInterface.php
│   │   │   └── AIServiceInterface.php
│   │   ├── Enums/
│   │   │   ├── BookingStatus.php
│   │   │   ├── PaymentStatus.php
│   │   │   ├── UserType.php
│   │   │   └── NotificationChannel.php
│   │   ├── Exceptions/
│   │   │   ├── Handler.php
│   │   │   ├── SupplierException.php
│   │   │   ├── PaymentException.php
│   │   │   ├── BookingException.php
│   │   │   └── ValidationException.php
│   │   ├── Http/
│   │   │   ├── Middleware/
│   │   │   │   ├── AuthenticateJWT.php
│   │   │   │   ├── CheckPermission.php
│   │   │   │   ├── RateLimiter.php
│   │   │   │   ├── SetLocale.php
│   │   │   │   ├── SetCurrency.php
│   │   │   │   └── LogRequest.php
│   │   │   └── Resources/
│   │   │       └── BaseResource.php
│   │   ├── Suppliers/                  # Adapter layer
│   │   │   ├── Flights/
│   │   │   │   ├── Contracts/
│   │   │   │   │   └── FlightSupplierInterface.php
│   │   │   │   ├── DTOs/
│   │   │   │   │   ├── FlightSearchDTO.php
│   │   │   │   │   ├── FlightBookingDTO.php
│   │   │   │   │   └── FlightResultDTO.php
│   │   │   │   ├── Adapters/
│   │   │   │   │   ├── DuffelAdapter.php
│   │   │   │   │   ├── AmadeusAdapter.php
│   │   │   │   │   ├── SabreAdapter.php
│   │   │   │   │   ├── MystiflyAdapter.php
│   │   │   │   │   └── TravelFusionAdapter.php
│   │   │   │   └── FlightSupplierManager.php  # Facade for all adapters
│   │   │   └── Hotels/
│   │   │       ├── Contracts/
│   │   │       │   └── HotelSupplierInterface.php
│   │   │       ├── DTOs/
│   │   │       ├── Adapters/
│   │   │       │   ├── RateHawkAdapter.php
│   │   │       │   ├── HotelbedsAdapter.php
│   │   │       │   └── TBOAdapter.php
│   │   │       └── HotelSupplierManager.php
│   │   ├── Payments/
│   │   │   ├── Contracts/
│   │   │   │   └── PaymentGatewayInterface.php
│   │   │   ├── Gateways/
│   │   │   │   ├── HyperPayGateway.php
│   │   │   │   ├── MoyasarGateway.php
│   │   │   │   ├── StripeGateway.php
│   │   │   │   └── STCPayGateway.php
│   │   │   └── PaymentManager.php
│   │   ├── AI/
│   │   │   ├── ClaudeService.php
│   │   │   ├── TripPlannerService.php
│   │   │   ├── SearchIntentService.php
│   │   │   ├── PricePredictionService.php
│   │   │   └── RecommendationService.php
│   │   └── Traits/
│   │       ├── HasAuditLog.php
│   │       ├── HasSoftDelete.php
│   │       └── HasUUID.php
│   │
│   └── Modules/                        # Business modules
│       │
│       ├── Auth/
│       │   ├── Controllers/
│       │   │   ├── AuthController.php
│       │   │   ├── SocialAuthController.php
│       │   │   └── PasswordController.php
│       │   ├── Services/
│       │   │   ├── AuthService.php
│       │   │   ├── TokenService.php
│       │   │   └── OTPService.php
│       │   ├── Repositories/
│       │   │   ├── UserRepository.php
│       │   │   └── RefreshTokenRepository.php
│       │   ├── Models/
│       │   │   ├── User.php
│       │   │   └── RefreshToken.php
│       │   ├── DTOs/
│       │   │   ├── RegisterDTO.php
│       │   │   └── LoginDTO.php
│       │   ├── Requests/
│       │   │   ├── RegisterRequest.php
│       │   │   ├── LoginRequest.php
│       │   │   └── ResetPasswordRequest.php
│       │   ├── Resources/
│       │   │   ├── UserResource.php
│       │   │   └── AuthTokenResource.php
│       │   ├── Events/
│       │   │   ├── UserRegistered.php
│       │   │   └── UserLoggedIn.php
│       │   ├── Listeners/
│       │   │   ├── SendWelcomeEmail.php
│       │   │   └── LogLoginActivity.php
│       │   └── Routes/
│       │       └── api.php
│       │
│       ├── Flights/
│       │   ├── Controllers/
│       │   │   ├── FlightSearchController.php
│       │   │   └── FlightBookingController.php
│       │   ├── Services/
│       │   │   ├── FlightSearchService.php
│       │   │   ├── FlightBookingService.php
│       │   │   ├── FlightAggregatorService.php  # Aggregate multi-supplier results
│       │   │   └── FlightCacheService.php
│       │   ├── Repositories/
│       │   │   ├── FlightBookingRepository.php
│       │   │   └── FlightSearchRepository.php
│       │   ├── Models/
│       │   │   ├── FlightBooking.php
│       │   │   ├── Airline.php
│       │   │   └── Airport.php
│       │   ├── DTOs/
│       │   ├── Events/
│       │   │   ├── FlightBooked.php
│       │   │   └── FlightCancelled.php
│       │   ├── Jobs/
│       │   │   ├── AggregateFlightResults.php
│       │   │   └── IssueFlightTicket.php
│       │   ├── Requests/
│       │   ├── Resources/
│       │   └── Routes/
│       │
│       ├── Hotels/
│       ├── Packages/
│       ├── Bookings/
│       ├── Payments/
│       ├── Wallet/
│       ├── Notifications/
│       ├── Reviews/
│       ├── Support/
│       ├── AI/
│       ├── Analytics/
│       ├── CMS/
│       └── Admin/
│
├── config/
│   ├── app.php
│   ├── auth.php
│   ├── database.php
│   ├── cache.php
│   ├── queue.php
│   ├── suppliers.php                   # Supplier config
│   ├── payments.php                    # Payment gateway config
│   ├── ai.php                          # AI service config
│   └── travel.php                      # Business rules config
│
├── database/
│   ├── migrations/
│   │   ├── 2025_01_01_000001_create_users_table.php
│   │   ├── 2025_01_01_000002_create_roles_table.php
│   │   ├── 2025_01_01_000003_create_permissions_table.php
│   │   ├── 2025_01_01_000004_create_countries_table.php
│   │   └── ...
│   ├── seeders/
│   │   ├── DatabaseSeeder.php
│   │   ├── RolesSeeder.php
│   │   ├── PermissionsSeeder.php
│   │   ├── CountriesSeeder.php
│   │   ├── AirlinesSeeder.php
│   │   └── AirportsSeeder.php
│   └── factories/
│
├── routes/
│   ├── api.php                         # Root route loader
│   └── console.php
│
├── tests/
│   ├── Unit/
│   │   ├── Services/
│   │   ├── Repositories/
│   │   └── Suppliers/
│   ├── Feature/
│   │   ├── Auth/
│   │   ├── Flights/
│   │   ├── Hotels/
│   │   ├── Bookings/
│   │   └── Payments/
│   └── Integration/
│       └── Suppliers/
│
├── storage/
├── resources/
│   ├── lang/
│   │   ├── ar/
│   │   │   ├── messages.php
│   │   │   ├── notifications.php
│   │   │   └── validation.php
│   │   └── en/
│   └── views/
│       └── emails/
│
├── .env.example
├── Dockerfile
├── docker-compose.yml
├── phpunit.xml
├── pint.json                           # Laravel Pint code style
├── phpstan.neon                        # Static analysis config
└── README.md
```

---

## Code Standards & Examples

### Model Example
```php
<?php
// app/Modules/Bookings/Models/Booking.php
namespace App\Modules\Bookings\Models;

use App\Core\Traits\HasUUID;
use App\Core\Traits\HasAuditLog;
use App\Core\Enums\BookingStatus;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

final class Booking extends Model
{
    use HasUUID, HasAuditLog, SoftDeletes;

    protected $table = 'bookings';
    protected $primaryKey = 'id';
    public $incrementing = false;
    protected $keyType = 'string';

    protected $fillable = [
        'reference', 'user_id', 'type', 'status',
        'currency', 'subtotal', 'taxes', 'fees',
        'discount', 'total', 'paid_amount',
    ];

    protected $casts = [
        'status'        => BookingStatus::class,
        'subtotal'      => 'decimal:4',
        'total'         => 'decimal:4',
        'cancellation_policy' => 'array',
        'created_at'    => 'datetime',
        'cancelled_at'  => 'datetime',
    ];

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    public function passengers(): HasMany
    {
        return $this->hasMany(Passenger::class);
    }

    public function isRefundable(): bool
    {
        return $this->status === BookingStatus::Confirmed
            && $this->cancellation_policy['type'] !== 'non_refundable';
    }

    public function getRemainingDueAttribute(): float
    {
        return max(0, $this->total - $this->paid_amount);
    }
}
```

### Service Example
```php
<?php
// app/Modules/Flights/Services/FlightSearchService.php
namespace App\Modules\Flights\Services;

use App\Core\Suppliers\Flights\FlightSupplierManager;
use App\Core\Suppliers\Flights\DTOs\FlightSearchDTO;
use App\Core\AI\RecommendationService;
use Illuminate\Support\Facades\Cache;

final class FlightSearchService
{
    public function __construct(
        private readonly FlightSupplierManager $supplierManager,
        private readonly FlightCacheService $cacheService,
        private readonly RecommendationService $aiRecommendation,
    ) {}

    public function search(FlightSearchDTO $dto, string $userId): array
    {
        $cacheKey = $this->buildCacheKey($dto);

        // Return from cache if available
        if ($cached = $this->cacheService->get($cacheKey)) {
            return $this->enrichWithAIScores($cached, $userId);
        }

        // Search all active suppliers concurrently
        $results = $this->supplierManager->searchAll($dto);

        // Aggregate, deduplicate, and sort results
        $aggregated = $this->aggregate($results);

        // Cache for 15 minutes
        $this->cacheService->put($cacheKey, $aggregated, ttl: 900);

        return $this->enrichWithAIScores($aggregated, $userId);
    }

    private function enrichWithAIScores(array $results, string $userId): array
    {
        $scores = $this->aiRecommendation->scoreFlights($results, $userId);

        return array_map(
            fn($result) => [...$result, 'ai_score' => $scores[$result['result_id']] ?? 0],
            $results,
        );
    }

    private function buildCacheKey(FlightSearchDTO $dto): string
    {
        return 'flight_search:' . md5(serialize($dto));
    }
}
```

### Supplier Adapter Example
```php
<?php
// app/Core/Suppliers/Flights/Adapters/DuffelAdapter.php
namespace App\Core\Suppliers\Flights\Adapters;

use App\Core\Suppliers\Flights\Contracts\FlightSupplierInterface;
use App\Core\Suppliers\Flights\DTOs\{FlightSearchDTO, FlightBookingDTO, FlightResultDTO};
use Illuminate\Support\Facades\Http;

final class DuffelAdapter implements FlightSupplierInterface
{
    private const BASE_URL = 'https://api.duffel.com/air';

    public function __construct(
        private readonly string $apiKey,
    ) {}

    public function search(FlightSearchDTO $dto): array
    {
        $response = Http::withToken($this->apiKey)
            ->withHeaders(['Duffel-Version' => 'v2'])
            ->timeout(10)
            ->post(self::BASE_URL . '/offer_requests', [
                'data' => $this->mapSearchRequest($dto),
            ]);

        if ($response->failed()) {
            throw new SupplierException('Duffel search failed: ' . $response->body());
        }

        return $this->mapResults($response->json('data'));
    }

    public function book(FlightBookingDTO $dto): array
    {
        // Implementation
    }

    public function cancel(string $bookingRef): array
    {
        // Implementation
    }

    private function mapSearchRequest(FlightSearchDTO $dto): array
    {
        return [
            'slices' => $dto->toSlices(),
            'passengers' => $dto->toPassengers(),
            'cabin_class' => $dto->cabinClass->value,
        ];
    }

    private function mapResults(array $data): array
    {
        return collect($data['offers'])->map(fn($offer) => new FlightResultDTO(
            resultId: $offer['id'],
            supplier: 'duffel',
            flights: $this->mapSegments($offer['slices']),
            pricing: $this->mapPricing($offer),
            baggage: $this->mapBaggage($offer),
        ))->all();
    }
}
```

### Controller Example
```php
<?php
// app/Modules/Flights/Controllers/FlightSearchController.php
namespace App\Modules\Flights\Controllers;

use App\Core\Http\Controllers\BaseController;
use App\Modules\Flights\Requests\FlightSearchRequest;
use App\Modules\Flights\Services\FlightSearchService;
use App\Modules\Flights\Resources\FlightSearchResource;

final class FlightSearchController extends BaseController
{
    public function __construct(
        private readonly FlightSearchService $searchService,
    ) {}

    /**
     * @OA\Post(
     *     path="/api/v1/flights/search",
     *     summary="Search for available flights",
     *     tags={"Flights"},
     *     ...
     * )
     */
    public function __invoke(FlightSearchRequest $request): JsonResponse
    {
        $dto = FlightSearchDTO::fromRequest($request);

        $results = $this->searchService->search($dto, $request->user()->id);

        return $this->success(
            data: FlightSearchResource::collection($results),
        );
    }
}
```

---

## Environment Configuration

```bash
# .env.example

APP_NAME="Saudi Travel Platform"
APP_ENV=production
APP_KEY=
APP_DEBUG=false
APP_URL=https://api.sauditraveltech.com

# Database
DB_CONNECTION=pgsql
DB_HOST=
DB_PORT=5432
DB_DATABASE=saudi_travel
DB_USERNAME=
DB_PASSWORD=

# Redis
REDIS_HOST=
REDIS_PASSWORD=
REDIS_PORT=6379

# Queue
QUEUE_CONNECTION=redis
QUEUE_PREFIX=stp

# Cache
CACHE_DRIVER=redis
CACHE_TTL=3600

# JWT
JWT_SECRET=
JWT_TTL=15                # Minutes
JWT_REFRESH_TTL=43200     # Minutes (30 days)

# Firebase
FIREBASE_PROJECT_ID=
FIREBASE_CREDENTIALS=

# Suppliers
DUFFEL_API_KEY=           # Loaded from Secret Manager
AMADEUS_API_KEY=
AMADEUS_API_SECRET=
RATEHAWK_API_KEY=

# Payments
HYPERPAY_ENTITY_ID=
HYPERPAY_ACCESS_TOKEN=
MOYASAR_API_KEY=

# AI
ANTHROPIC_API_KEY=        # Loaded from Secret Manager
CLAUDE_MODEL=claude-sonnet-4-6

# Google Cloud
GOOGLE_CLOUD_PROJECT=saudi-travel-prod
GOOGLE_CLOUD_STORAGE_BUCKET=

# Mail
MAIL_MAILER=postmark
POSTMARK_TOKEN=

# SMS
UNIFONIC_APP_SID=
UNIFONIC_SENDER_ID=SaudiTravel
```
