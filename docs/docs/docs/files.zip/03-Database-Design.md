# Database Design Document
## Saudi Travel Platform — PostgreSQL Schema
**Version:** 1.0.0

---

## Design Principles
- **UUID primary keys** for all tables (avoids sequential ID enumeration attacks)
- **Soft deletes** on customer-facing data (deleted_at timestamps)
- **Audit fields** on all tables (created_at, updated_at, created_by, updated_by)
- **Normalized** to 3NF minimum, denormalized only where performance requires it
- **JSONB** for dynamic supplier-specific data to avoid schema migrations for every supplier
- **Partitioning** on high-volume tables (bookings, api_logs, audit_logs) by date

---

## Tables

### 1. Identity & Access Management

```sql
-- users
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255) UNIQUE NOT NULL,
    phone           VARCHAR(20) UNIQUE,
    password_hash   VARCHAR(255),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    first_name_ar   VARCHAR(100),
    last_name_ar    VARCHAR(100),
    avatar_url      TEXT,
    date_of_birth   DATE,
    gender          SMALLINT,               -- 1=Male, 2=Female
    nationality_id  UUID REFERENCES countries(id),
    language        VARCHAR(10) DEFAULT 'ar',
    currency        VARCHAR(3) DEFAULT 'SAR',
    status          SMALLINT DEFAULT 1,     -- 1=Active, 2=Suspended, 3=Banned
    email_verified_at  TIMESTAMPTZ,
    phone_verified_at  TIMESTAMPTZ,
    last_login_at   TIMESTAMPTZ,
    last_login_ip   INET,
    firebase_uid    VARCHAR(255) UNIQUE,
    google_id       VARCHAR(255) UNIQUE,
    apple_id        VARCHAR(255) UNIQUE,
    mfa_enabled     BOOLEAN DEFAULT FALSE,
    mfa_secret      VARCHAR(255),           -- TOTP secret, encrypted
    type            SMALLINT DEFAULT 1,     -- 1=Customer, 2=Agent, 3=Corporate, 4=Staff
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    deleted_at      TIMESTAMPTZ
);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_users_type ON users(type);

-- roles
CREATE TABLE roles (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(100) UNIQUE NOT NULL,
    name_ar     VARCHAR(100),
    slug        VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    is_system   BOOLEAN DEFAULT FALSE,
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- permissions
CREATE TABLE permissions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(200) UNIQUE NOT NULL,
    slug        VARCHAR(200) UNIQUE NOT NULL,
    module      VARCHAR(100) NOT NULL,
    description TEXT,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- role_permissions
CREATE TABLE role_permissions (
    role_id       UUID REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID REFERENCES permissions(id) ON DELETE CASCADE,
    PRIMARY KEY (role_id, permission_id)
);

-- user_roles
CREATE TABLE user_roles (
    user_id    UUID REFERENCES users(id) ON DELETE CASCADE,
    role_id    UUID REFERENCES roles(id) ON DELETE CASCADE,
    granted_by UUID REFERENCES users(id),
    granted_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (user_id, role_id)
);

-- refresh_tokens
CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash  VARCHAR(255) NOT NULL,
    device_id   VARCHAR(255),
    device_name VARCHAR(255),
    ip_address  INET,
    user_agent  TEXT,
    expires_at  TIMESTAMPTZ NOT NULL,
    revoked_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX idx_refresh_tokens_user ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_hash ON refresh_tokens(token_hash);
```

### 2. Reference Data

```sql
-- countries
CREATE TABLE countries (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name        VARCHAR(100) NOT NULL,
    name_ar     VARCHAR(100),
    iso2        CHAR(2) UNIQUE NOT NULL,
    iso3        CHAR(3) UNIQUE NOT NULL,
    phone_code  VARCHAR(10),
    currency    VARCHAR(3),
    region      VARCHAR(50),
    flag_url    TEXT,
    is_active   BOOLEAN DEFAULT TRUE,
    sort_order  INT DEFAULT 0
);

-- cities
CREATE TABLE cities (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    country_id  UUID NOT NULL REFERENCES countries(id),
    name        VARCHAR(200) NOT NULL,
    name_ar     VARCHAR(200),
    latitude    DECIMAL(10, 8),
    longitude   DECIMAL(11, 8),
    timezone    VARCHAR(50),
    is_active   BOOLEAN DEFAULT TRUE
);
CREATE INDEX idx_cities_country ON cities(country_id);

-- currencies
CREATE TABLE currencies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            CHAR(3) UNIQUE NOT NULL,
    name            VARCHAR(100) NOT NULL,
    name_ar         VARCHAR(100),
    symbol          VARCHAR(10),
    decimal_places  SMALLINT DEFAULT 2,
    is_active       BOOLEAN DEFAULT TRUE
);

-- exchange_rates (refreshed hourly)
CREATE TABLE exchange_rates (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    from_currency   CHAR(3) NOT NULL,
    to_currency     CHAR(3) NOT NULL,
    rate            DECIMAL(18, 8) NOT NULL,
    source          VARCHAR(50),
    fetched_at      TIMESTAMPTZ NOT NULL,
    UNIQUE(from_currency, to_currency)
);

-- airlines
CREATE TABLE airlines (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    iata_code   CHAR(2) UNIQUE,
    icao_code   CHAR(3) UNIQUE,
    name        VARCHAR(200) NOT NULL,
    name_ar     VARCHAR(200),
    logo_url    TEXT,
    country_id  UUID REFERENCES countries(id),
    is_active   BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- airports
CREATE TABLE airports (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    iata_code   CHAR(3) UNIQUE NOT NULL,
    icao_code   CHAR(4) UNIQUE,
    name        VARCHAR(200) NOT NULL,
    name_ar     VARCHAR(200),
    city_id     UUID REFERENCES cities(id),
    country_id  UUID NOT NULL REFERENCES countries(id),
    latitude    DECIMAL(10, 8),
    longitude   DECIMAL(11, 8),
    timezone    VARCHAR(50),
    terminal_count SMALLINT,
    type        VARCHAR(20),            -- international, domestic, regional
    is_active   BOOLEAN DEFAULT TRUE
);
CREATE INDEX idx_airports_iata ON airports(iata_code);
CREATE INDEX idx_airports_city ON airports(city_id);
```

### 3. Supplier Management

```sql
-- suppliers
CREATE TABLE suppliers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(200) NOT NULL,
    code            VARCHAR(50) UNIQUE NOT NULL,
    type            VARCHAR(50) NOT NULL,  -- flight, hotel, car, transfer, package
    status          SMALLINT DEFAULT 1,    -- 1=Active, 2=Testing, 3=Disabled
    priority        INT DEFAULT 100,        -- lower = higher priority
    config          JSONB DEFAULT '{}',    -- API URLs, timeouts, etc
    credentials     JSONB DEFAULT '{}',    -- Encrypted keys (stored in Secret Manager)
    markup_type     VARCHAR(20),           -- percentage, fixed
    markup_value    DECIMAL(10, 4),
    supported_markets JSONB DEFAULT '[]',  -- country codes
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- api_logs (partitioned by month)
CREATE TABLE api_logs (
    id              UUID DEFAULT gen_random_uuid(),
    supplier_id     UUID REFERENCES suppliers(id),
    user_id         UUID REFERENCES users(id),
    endpoint        TEXT NOT NULL,
    method          VARCHAR(10),
    request_payload JSONB,
    response_payload JSONB,
    status_code     SMALLINT,
    duration_ms     INT,
    error_message   TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

CREATE TABLE api_logs_2025_01 PARTITION OF api_logs
    FOR VALUES FROM ('2025-01-01') TO ('2025-02-01');
-- Create monthly partitions via automated script
```

### 4. Flights

```sql
-- flight_searches (for analytics and AI training)
CREATE TABLE flight_searches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID REFERENCES users(id),
    session_id      VARCHAR(100),
    origin          CHAR(3) NOT NULL,
    destination     CHAR(3) NOT NULL,
    departure_date  DATE NOT NULL,
    return_date     DATE,
    trip_type       SMALLINT NOT NULL,   -- 1=one-way, 2=round, 3=multi
    cabin_class     SMALLINT DEFAULT 1,  -- 1=economy, 2=business, 3=first
    adults          SMALLINT DEFAULT 1,
    children        SMALLINT DEFAULT 0,
    infants         SMALLINT DEFAULT 0,
    currency        CHAR(3) DEFAULT 'SAR',
    results_count   INT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- flight_results_cache (Redis preferred, DB fallback)
CREATE TABLE flight_cache (
    cache_key       VARCHAR(255) PRIMARY KEY,
    results         JSONB NOT NULL,
    supplier_id     UUID REFERENCES suppliers(id),
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 5. Hotels

```sql
-- hotels (static content)
CREATE TABLE hotels (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    supplier_hotel_id VARCHAR(255),      -- Supplier's internal ID
    supplier_id     UUID REFERENCES suppliers(id),
    name            VARCHAR(300) NOT NULL,
    name_ar         VARCHAR(300),
    description     TEXT,
    description_ar  TEXT,
    star_rating     SMALLINT,
    property_type   VARCHAR(50),        -- hotel, apartment, resort, villa
    city_id         UUID REFERENCES cities(id),
    country_id      UUID REFERENCES countries(id),
    address         TEXT,
    address_ar      TEXT,
    latitude        DECIMAL(10, 8),
    longitude       DECIMAL(11, 8),
    phone           VARCHAR(20),
    email           VARCHAR(255),
    website         TEXT,
    amenities       JSONB DEFAULT '[]', -- Array of amenity codes
    policies        JSONB DEFAULT '{}', -- Check-in, check-out, pets, etc
    images          JSONB DEFAULT '[]', -- Array of image URLs
    is_active       BOOLEAN DEFAULT TRUE,
    content_updated_at TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(supplier_id, supplier_hotel_id)
);
CREATE INDEX idx_hotels_city ON hotels(city_id);
CREATE INDEX idx_hotels_country ON hotels(country_id);
CREATE INDEX idx_hotels_geo ON hotels USING GIST(
    ll_to_earth(latitude::float8, longitude::float8)
);

-- hotel_rooms (room types per hotel)
CREATE TABLE hotel_rooms (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hotel_id        UUID NOT NULL REFERENCES hotels(id),
    supplier_room_id VARCHAR(255),
    name            VARCHAR(300) NOT NULL,
    name_ar         VARCHAR(300),
    description     TEXT,
    room_type       VARCHAR(100),
    bed_type        VARCHAR(100),
    max_occupancy   SMALLINT,
    max_adults      SMALLINT,
    max_children    SMALLINT,
    size_sqm        DECIMAL(6, 2),
    amenities       JSONB DEFAULT '[]',
    images          JSONB DEFAULT '[]',
    is_active       BOOLEAN DEFAULT TRUE
);
```

### 6. Bookings (Core)

```sql
-- bookings (master table)
CREATE TABLE bookings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference       VARCHAR(20) UNIQUE NOT NULL, -- STT-2025-000001
    user_id         UUID NOT NULL REFERENCES users(id),
    agent_id        UUID REFERENCES users(id),   -- If booked by agent
    corporate_id    UUID REFERENCES corporate_accounts(id),
    type            VARCHAR(20) NOT NULL,         -- flight, hotel, package, car, transfer
    status          VARCHAR(30) NOT NULL DEFAULT 'pending',
    -- pending, confirmed, ticketed, cancelled, refunded, completed
    source          VARCHAR(30),                  -- web, ios, android, b2b, api
    currency        CHAR(3) NOT NULL DEFAULT 'SAR',
    subtotal        DECIMAL(12, 4) NOT NULL,
    taxes           DECIMAL(12, 4) DEFAULT 0,
    fees            DECIMAL(12, 4) DEFAULT 0,
    discount        DECIMAL(12, 4) DEFAULT 0,
    total           DECIMAL(12, 4) NOT NULL,
    paid_amount     DECIMAL(12, 4) DEFAULT 0,
    refunded_amount DECIMAL(12, 4) DEFAULT 0,
    coupon_id       UUID REFERENCES coupons(id),
    gift_card_id    UUID REFERENCES gift_cards(id),
    notes           TEXT,
    internal_notes  TEXT,
    supplier_reference VARCHAR(100),
    pnr             VARCHAR(50),
    cancellation_policy JSONB,
    cancelled_at    TIMESTAMPTZ,
    cancellation_reason TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- flight_bookings
CREATE TABLE flight_bookings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    supplier_id     UUID NOT NULL REFERENCES suppliers(id),
    pnr             VARCHAR(50),
    ticket_numbers  JSONB DEFAULT '[]',
    origin          CHAR(3) NOT NULL,
    destination     CHAR(3) NOT NULL,
    departure_at    TIMESTAMPTZ NOT NULL,
    arrival_at      TIMESTAMPTZ NOT NULL,
    return_departure_at TIMESTAMPTZ,
    return_arrival_at   TIMESTAMPTZ,
    cabin_class     VARCHAR(20),
    airline_id      UUID REFERENCES airlines(id),
    flight_segments JSONB NOT NULL,   -- Full itinerary details
    fare_rules      JSONB,
    baggage_info    JSONB,
    status          VARCHAR(30) DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- hotel_bookings
CREATE TABLE hotel_bookings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    hotel_id        UUID NOT NULL REFERENCES hotels(id),
    supplier_id     UUID NOT NULL REFERENCES suppliers(id),
    supplier_booking_ref VARCHAR(100),
    room_id         UUID REFERENCES hotel_rooms(id),
    check_in        DATE NOT NULL,
    check_out       DATE NOT NULL,
    nights          SMALLINT NOT NULL,
    rooms           SMALLINT DEFAULT 1,
    adults          SMALLINT NOT NULL,
    children        SMALLINT DEFAULT 0,
    board_type      VARCHAR(50),      -- RO, BB, HB, FB, AI
    room_details    JSONB,
    status          VARCHAR(30) DEFAULT 'pending',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- passengers
CREATE TABLE passengers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    user_id         UUID REFERENCES users(id),
    type            SMALLINT NOT NULL,    -- 1=Adult, 2=Child, 3=Infant
    title           VARCHAR(10),
    first_name      VARCHAR(100) NOT NULL,
    last_name       VARCHAR(100) NOT NULL,
    first_name_ar   VARCHAR(100),
    last_name_ar    VARCHAR(100),
    date_of_birth   DATE,
    gender          SMALLINT,
    nationality_id  UUID REFERENCES countries(id),
    passport_number VARCHAR(50),          -- Encrypted
    passport_expiry DATE,
    passport_country_id UUID REFERENCES countries(id),
    national_id     VARCHAR(50),          -- Encrypted
    frequent_flyer  JSONB DEFAULT '[]',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 7. Payments & Financial

```sql
-- payments
CREATE TABLE payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    gateway         VARCHAR(50) NOT NULL,   -- hyperpay, moyasar, stripe, wallet
    gateway_tx_id   VARCHAR(255),
    method          VARCHAR(50),            -- card, apple_pay, google_pay, stc_pay
    card_brand      VARCHAR(20),
    card_last4      CHAR(4),
    amount          DECIMAL(12, 4) NOT NULL,
    currency        CHAR(3) NOT NULL,
    status          VARCHAR(30) NOT NULL,   -- pending, completed, failed, refunded
    gateway_response JSONB,
    failure_reason  TEXT,
    refunded_at     TIMESTAMPTZ,
    refund_reference VARCHAR(255),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- wallets
CREATE TABLE wallets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID UNIQUE NOT NULL REFERENCES users(id),
    currency        CHAR(3) DEFAULT 'SAR',
    balance         DECIMAL(12, 4) DEFAULT 0,
    held_balance    DECIMAL(12, 4) DEFAULT 0,  -- Reserved for pending bookings
    lifetime_earned DECIMAL(12, 4) DEFAULT 0,
    lifetime_spent  DECIMAL(12, 4) DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- wallet_transactions
CREATE TABLE wallet_transactions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    wallet_id       UUID NOT NULL REFERENCES wallets(id),
    booking_id      UUID REFERENCES bookings(id),
    type            VARCHAR(30) NOT NULL,    -- credit, debit, hold, release, refund
    amount          DECIMAL(12, 4) NOT NULL,
    balance_before  DECIMAL(12, 4) NOT NULL,
    balance_after   DECIMAL(12, 4) NOT NULL,
    description     TEXT,
    description_ar  TEXT,
    reference       VARCHAR(100),
    created_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- coupons
CREATE TABLE coupons (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(50) UNIQUE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    name_ar         VARCHAR(200),
    description     TEXT,
    type            VARCHAR(20) NOT NULL,   -- percentage, fixed
    value           DECIMAL(10, 4) NOT NULL,
    min_booking_value DECIMAL(12, 4),
    max_discount    DECIMAL(12, 4),
    usage_limit     INT,
    usage_count     INT DEFAULT 0,
    per_user_limit  INT DEFAULT 1,
    applicable_to   JSONB DEFAULT '[]',     -- flight, hotel, package, etc
    conditions      JSONB DEFAULT '{}',
    valid_from      TIMESTAMPTZ NOT NULL,
    valid_until     TIMESTAMPTZ NOT NULL,
    is_active       BOOLEAN DEFAULT TRUE,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- gift_cards
CREATE TABLE gift_cards (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(50) UNIQUE NOT NULL,
    issued_to       UUID REFERENCES users(id),
    original_value  DECIMAL(12, 4) NOT NULL,
    remaining_value DECIMAL(12, 4) NOT NULL,
    currency        CHAR(3) DEFAULT 'SAR',
    valid_until     DATE,
    is_active       BOOLEAN DEFAULT TRUE,
    purchased_booking_id UUID REFERENCES bookings(id),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- invoices (ZATCA compliant)
CREATE TABLE invoices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    invoice_number  VARCHAR(50) UNIQUE NOT NULL,
    type            VARCHAR(20),         -- standard, simplified (ZATCA)
    subtotal        DECIMAL(12, 4) NOT NULL,
    vat_amount      DECIMAL(12, 4) NOT NULL,  -- 15% VAT in Saudi Arabia
    total           DECIMAL(12, 4) NOT NULL,
    currency        CHAR(3) NOT NULL,
    status          VARCHAR(20) DEFAULT 'draft',
    pdf_url         TEXT,
    zatca_uuid      VARCHAR(255),        -- ZATCA compliance UUID
    qr_code         TEXT,                -- ZATCA QR code
    issued_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at      TIMESTAMPTZ DEFAULT NOW()
);
```

### 8. Content & Communication

```sql
-- notifications
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id),
    booking_id      UUID REFERENCES bookings(id),
    type            VARCHAR(100) NOT NULL,   -- booking_confirmed, flight_delay, etc
    channel         VARCHAR(20) NOT NULL,    -- push, email, sms, in_app
    title           VARCHAR(300),
    title_ar        VARCHAR(300),
    body            TEXT,
    body_ar         TEXT,
    data            JSONB DEFAULT '{}',
    is_read         BOOLEAN DEFAULT FALSE,
    read_at         TIMESTAMPTZ,
    sent_at         TIMESTAMPTZ,
    failed_at       TIMESTAMPTZ,
    failure_reason  TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);
CREATE INDEX idx_notifications_user ON notifications(user_id, is_read, created_at DESC);

-- reviews
CREATE TABLE reviews (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    booking_id      UUID NOT NULL REFERENCES bookings(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    entity_type     VARCHAR(50) NOT NULL,   -- hotel, flight, package
    entity_id       UUID NOT NULL,
    rating          SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    title           VARCHAR(300),
    body            TEXT,
    pros            TEXT,
    cons            TEXT,
    status          VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
    helpful_count   INT DEFAULT 0,
    response        TEXT,                   -- Supplier response
    response_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- support_tickets
CREATE TABLE support_tickets (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    reference       VARCHAR(20) UNIQUE NOT NULL,
    user_id         UUID NOT NULL REFERENCES users(id),
    booking_id      UUID REFERENCES bookings(id),
    assigned_to     UUID REFERENCES users(id),
    category        VARCHAR(100),
    priority        SMALLINT DEFAULT 2,  -- 1=Low, 2=Medium, 3=High, 4=Critical
    status          VARCHAR(30) DEFAULT 'open', -- open, in_progress, waiting, resolved, closed
    subject         VARCHAR(500) NOT NULL,
    first_response_at TIMESTAMPTZ,
    resolved_at     TIMESTAMPTZ,
    satisfaction_score SMALLINT,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ticket_messages
CREATE TABLE ticket_messages (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ticket_id       UUID NOT NULL REFERENCES support_tickets(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    body            TEXT NOT NULL,
    is_internal     BOOLEAN DEFAULT FALSE,
    attachments     JSONB DEFAULT '[]',
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- favorites
CREATE TABLE favorites (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id),
    entity_type     VARCHAR(50) NOT NULL,  -- hotel, destination, package
    entity_id       UUID NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, entity_type, entity_id)
);
```

### 9. Corporate & B2B

```sql
-- corporate_accounts
CREATE TABLE corporate_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(300) NOT NULL,
    name_ar         VARCHAR(300),
    cr_number       VARCHAR(50),           -- Commercial Registration (Saudi)
    vat_number      VARCHAR(50),
    contact_email   VARCHAR(255),
    contact_phone   VARCHAR(20),
    credit_limit    DECIMAL(12, 4) DEFAULT 0,
    used_credit     DECIMAL(12, 4) DEFAULT 0,
    payment_terms   INT DEFAULT 30,        -- Days
    status          SMALLINT DEFAULT 1,
    travel_policy   JSONB DEFAULT '{}',
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- corporate_members
CREATE TABLE corporate_members (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    corporate_id    UUID NOT NULL REFERENCES corporate_accounts(id),
    user_id         UUID NOT NULL REFERENCES users(id),
    role            VARCHAR(50) DEFAULT 'employee',  -- employee, manager, admin
    department      VARCHAR(100),
    cost_center     VARCHAR(100),
    spending_limit  DECIMAL(12, 4),
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(corporate_id, user_id)
);
```

### 10. Audit & Monitoring

```sql
-- audit_logs
CREATE TABLE audit_logs (
    id              UUID DEFAULT gen_random_uuid(),
    user_id         UUID REFERENCES users(id),
    action          VARCHAR(200) NOT NULL,
    entity_type     VARCHAR(100),
    entity_id       UUID,
    old_values      JSONB,
    new_values      JSONB,
    ip_address      INET,
    user_agent      TEXT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
) PARTITION BY RANGE (created_at);

-- settings
CREATE TABLE settings (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key         VARCHAR(200) UNIQUE NOT NULL,
    value       JSONB,
    type        VARCHAR(50),    -- string, integer, boolean, json
    group       VARCHAR(100),
    label       VARCHAR(300),
    label_ar    VARCHAR(300),
    is_public   BOOLEAN DEFAULT FALSE,
    updated_by  UUID REFERENCES users(id),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);
```

---

## Indexes Strategy

```sql
-- Performance-critical indexes
CREATE INDEX idx_bookings_user ON bookings(user_id, created_at DESC);
CREATE INDEX idx_bookings_status ON bookings(status);
CREATE INDEX idx_bookings_reference ON bookings(reference);
CREATE INDEX idx_payments_booking ON payments(booking_id);
CREATE INDEX idx_passengers_booking ON passengers(booking_id);
CREATE INDEX idx_hotel_searches_dates ON flight_searches(departure_date, origin, destination);
```

---

## Redis Keys Structure

```
# Session management
session:{token_hash} → user_id (TTL: 30d)

# Flight search cache
flight_search:{hash_of_params} → JSON results (TTL: 15min)

# Hotel search cache
hotel_search:{hash_of_params} → JSON results (TTL: 30min)

# Exchange rates
exchange_rate:{from}:{to} → rate (TTL: 1h)

# Rate limiting
rate_limit:{ip}:{endpoint} → count (TTL: 1min)

# User session
user_session:{user_id} → JSON (TTL: 24h)

# Booking lock (prevent duplicate bookings)
booking_lock:{user_id}:{search_id} → 1 (TTL: 10min)
```
