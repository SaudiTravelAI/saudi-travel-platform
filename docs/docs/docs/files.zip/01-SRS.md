# Software Requirements Specification (SRS)
## Saudi Travel Platform
**Version:** 1.0.0  
**Date:** 2025  
**Company:** Saudi Travel Technologies  
**Classification:** Confidential

---

## Table of Contents
1. Introduction
2. Overall Description
3. Functional Requirements
4. Non-Functional Requirements
5. System Constraints
6. External Interface Requirements

---

## 1. Introduction

### 1.1 Purpose
This document defines the complete software requirements for the Saudi Travel Platform (STP), an enterprise-grade AI-powered Online Travel Agency (OTA) targeting Saudi Arabia, the GCC region, the Middle East, and future global expansion.

### 1.2 Scope
The Saudi Travel Platform is a multi-tenant, cloud-native OTA that provides flight booking, hotel reservations, holiday packages, transfers, car rentals, visa services, travel insurance, and ancillary travel products. The platform serves B2C consumers, B2B travel agents, and enterprise corporate clients.

### 1.3 Definitions
| Term | Definition |
|------|------------|
| OTA | Online Travel Agency |
| GDS | Global Distribution System |
| PNR | Passenger Name Record |
| NDC | New Distribution Capability (IATA standard) |
| B2B | Business-to-Business |
| B2C | Business-to-Consumer |
| API | Application Programming Interface |
| RBAC | Role-Based Access Control |
| GCC | Gulf Cooperation Council |

### 1.4 Overview
The platform is divided into the following major components:
- Mobile Applications (Android & iOS via Flutter)
- Web Application (Flutter Web)
- Admin Dashboard (Flutter Web)
- B2B & Corporate Portals
- Backend API (Laravel 12 / PHP 8.4)
- AI Engine (Claude API integration)
- Data layer (PostgreSQL, Redis, GCS)

---

## 2. Overall Description

### 2.1 Product Perspective
The Saudi Travel Platform is a greenfield enterprise system designed to operate as a standalone SaaS platform. It integrates with multiple Global Distribution Systems (GDS), hotel bed banks, payment gateways, and AI services through a unified supplier abstraction layer.

### 2.2 Product Functions Summary
- **Search & Book:** Flights, Hotels, Cars, Transfers, Packages, Activities
- **Manage:** Bookings, Itineraries, Passengers, Documents
- **Pay:** Multi-gateway payments, Wallet, Coupons, Gift Cards
- **Assist:** AI Trip Planner, AI Chat Assistant, Price Prediction
- **Administer:** CMS, Settings, Reports, User Management
- **Integrate:** Travel Agents Portal, Corporate Portal, Affiliate Program

### 2.3 User Classes
| Class | Description | Access Level |
|-------|-------------|--------------|
| Guest | Unauthenticated visitor | Search only |
| Customer | Registered end-user | Full B2C features |
| Travel Agent | Registered agent | B2B pricing and tools |
| Corporate User | Enterprise employee | Corporate account features |
| Corporate Admin | Enterprise account manager | Manage team bookings |
| Affiliate | Partner referral account | Tracking and commissions |
| Support Agent | Customer service staff | CRM and booking management |
| Content Manager | CMS operator | Content publishing |
| Finance | Finance department | Financial reports and refunds |
| Super Admin | Platform administrator | Full system access |

### 2.4 Operating Environment
- Cloud: Google Cloud Platform (GCP) — Middle East region (me-central1)
- Backend: Cloud Run (serverless containers)
- Database: Cloud SQL for PostgreSQL (HA configuration)
- Cache: Redis via Memorystore
- Storage: Google Cloud Storage
- CDN: Cloud CDN via Cloud Load Balancing

---

## 3. Functional Requirements

### 3.1 Authentication & Authorization
- FR-AUTH-001: System shall support email/password registration with email verification
- FR-AUTH-002: System shall support Google OAuth2 and Apple Sign-In
- FR-AUTH-003: System shall implement JWT with refresh token rotation
- FR-AUTH-004: System shall enforce role-based access control (RBAC) on all endpoints
- FR-AUTH-005: System shall support multi-factor authentication (MFA) via OTP
- FR-AUTH-006: System shall implement session management with configurable expiry
- FR-AUTH-007: System shall support corporate SSO via SAML 2.0

### 3.2 Flight Booking
- FR-FLT-001: System shall support one-way, round-trip, and multi-city search
- FR-FLT-002: System shall aggregate results from multiple GDS/airline APIs simultaneously
- FR-FLT-003: System shall display fare breakdown (base fare, taxes, fees, surcharges)
- FR-FLT-004: System shall support cabin classes (Economy, Business, First)
- FR-FLT-005: System shall support seat selection where available
- FR-FLT-006: System shall support ancillary services (baggage, meals, lounge access)
- FR-FLT-007: System shall handle hold and ticketing workflows
- FR-FLT-008: System shall support PNR retrieval and management
- FR-FLT-009: System shall send e-ticket and itinerary via email and push notification
- FR-FLT-010: System shall support NDC-compliant booking for participating airlines

### 3.3 Hotel Booking
- FR-HTL-001: System shall support search by destination, dates, guests, and rooms
- FR-HTL-002: System shall aggregate inventory from multiple bed banks
- FR-HTL-003: System shall display room types, amenities, and cancellation policies
- FR-HTL-004: System shall support map-based hotel search
- FR-HTL-005: System shall display hotel photos, ratings, and guest reviews
- FR-HTL-006: System shall support static content management for hotel descriptions
- FR-HTL-007: System shall handle special requests (early check-in, dietary needs)
- FR-HTL-008: System shall support B2B net rates with markup configuration

### 3.4 Holiday Packages
- FR-PKG-001: System shall support dynamic package creation (flight + hotel combinations)
- FR-PKG-002: System shall support pre-configured package offerings via CMS
- FR-PKG-003: System shall allow custom itinerary building by travel agents
- FR-PKG-004: System shall calculate combined pricing and apply package discounts

### 3.5 Payment Processing
- FR-PAY-001: System shall integrate with HyperPay, Moyasar, Stripe, and PayPal
- FR-PAY-002: System shall support Apple Pay, Google Pay, and STC Pay
- FR-PAY-003: System shall support installment payments via BNPL providers
- FR-PAY-004: System shall implement a customer wallet with top-up and refund flows
- FR-PAY-005: System shall support multi-currency pricing with real-time FX rates
- FR-PAY-006: System shall generate invoices compliant with ZATCA (Saudi e-invoicing)
- FR-PAY-007: System shall handle refunds with automated supplier reconciliation

### 3.6 AI Features
- FR-AI-001: System shall provide an AI Trip Planner that generates complete itineraries
- FR-AI-002: System shall implement AI Smart Search with natural language queries
- FR-AI-003: System shall provide AI-powered price prediction with confidence scores
- FR-AI-004: System shall offer an AI Chat Assistant available 24/7
- FR-AI-005: System shall generate personalized flight and hotel recommendations
- FR-AI-006: System shall support AI-generated marketing content for promotions

### 3.7 Notifications
- FR-NOT-001: System shall send booking confirmations via email, SMS, and push
- FR-NOT-002: System shall send flight status updates (delays, gate changes)
- FR-NOT-003: System shall send check-in reminders 24 hours before departure
- FR-NOT-004: System shall support promotional notifications with personalization
- FR-NOT-005: System shall support in-app notification center with read/unread status

### 3.8 Corporate & B2B
- FR-B2B-001: System shall support travel policy enforcement for corporate accounts
- FR-B2B-002: System shall provide multi-level approval workflows for bookings
- FR-B2B-003: System shall generate consolidated corporate invoices
- FR-B2B-004: System shall provide travel agent sub-account management
- FR-B2B-005: System shall support credit limit configuration for B2B accounts

---

## 4. Non-Functional Requirements

### 4.1 Performance
- NFR-PERF-001: Flight search results must return within 3 seconds (p95)
- NFR-PERF-002: Hotel search results must return within 2 seconds (p95)
- NFR-PERF-003: Page load time must be under 2 seconds on 4G networks
- NFR-PERF-004: API throughput must support 1,000 concurrent users at launch
- NFR-PERF-005: System must scale horizontally to 10,000 concurrent users

### 4.2 Availability
- NFR-AVAIL-001: System uptime target: 99.9% (excluding scheduled maintenance)
- NFR-AVAIL-002: Planned maintenance windows must not exceed 2 hours/month
- NFR-AVAIL-003: Recovery Time Objective (RTO): < 1 hour
- NFR-AVAIL-004: Recovery Point Objective (RPO): < 15 minutes

### 4.3 Security
- NFR-SEC-001: All communications must use TLS 1.3
- NFR-SEC-002: Passwords must be hashed using bcrypt (min cost factor 12)
- NFR-SEC-003: Sensitive data at rest must be encrypted using AES-256
- NFR-SEC-004: PCI DSS compliance required for cardholder data handling
- NFR-SEC-005: OWASP Top 10 vulnerabilities must be mitigated
- NFR-SEC-006: Penetration testing required before production launch
- NFR-SEC-007: All API endpoints must implement rate limiting

### 4.4 Scalability
- NFR-SCALE-001: Architecture must support horizontal scaling without downtime
- NFR-SCALE-002: Database must support read replicas for query offloading
- NFR-SCALE-003: Static assets must be served via CDN globally
- NFR-SCALE-004: Background jobs must be processed via distributed queue system

### 4.5 Maintainability
- NFR-MAINT-001: Code coverage must exceed 80% for critical business logic
- NFR-MAINT-002: All APIs must be documented using OpenAPI 3.1 specification
- NFR-MAINT-003: CI/CD pipeline must enforce automated testing before deployment
- NFR-MAINT-004: Deployment must support zero-downtime rolling updates

### 4.6 Localization
- NFR-L10N-001: UI must fully support Arabic (RTL) and English (LTR)
- NFR-L10N-002: Dates must display in Gregorian and Hijri calendars
- NFR-L10N-003: Currency must display in SAR, USD, EUR, AED, and KWD
- NFR-L10N-004: All SMS and email templates must support both languages

---

## 5. System Constraints
- Must comply with Saudi Communications and Information Technology Commission (CITC) regulations
- Must comply with Personal Data Protection Law (PDPL) of Saudi Arabia
- Payment processing must adhere to Saudi Arabian Monetary Authority (SAMA) guidelines
- ZATCA e-invoicing compliance is mandatory for B2B invoices
- Must obtain IATA accreditation or partner with accredited consolidator

---

## 6. External Interface Requirements

### 6.1 Supplier APIs
| Supplier | Type | Protocol |
|----------|------|----------|
| Duffel | Flights | REST/NDC |
| Amadeus | Flights/Hotels | REST |
| Sabre | Flights | SOAP/REST |
| TBO Holidays | Packages/Hotels | REST |
| RateHawk | Hotels | REST |
| Hotelbeds | Hotels | REST |
| Juniper | Packages | XML/REST |
| TravelgateX | Multi-product | GraphQL |

### 6.2 Payment Gateways
| Gateway | Market | Protocol |
|---------|--------|----------|
| HyperPay | Saudi Arabia / MENA | REST |
| Moyasar | Saudi Arabia | REST |
| Stripe | International | REST |
| PayPal | International | REST |
| STC Pay | Saudi Arabia | REST |

### 6.3 Third-Party Services
| Service | Purpose |
|---------|---------|
| Firebase | Auth, Push Notifications, Analytics, Crashlytics |
| Google Maps Platform | Maps, Places, Geocoding |
| Google Cloud Secret Manager | Secrets management |
| Anthropic Claude API | AI features |
| SendGrid / Postmark | Transactional email |
| Twilio / Unifonic | SMS delivery |
