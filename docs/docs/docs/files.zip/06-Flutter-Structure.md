# Flutter Project Structure
## Saudi Travel Platform — Mobile & Web
**Stack:** Flutter Latest · Riverpod · GoRouter · Material 3

---

## Project Structure

```
saudi_travel_app/
│
├── lib/
│   │
│   ├── main.dart                        # App entry point
│   ├── app.dart                         # MaterialApp configuration
│   │
│   ├── core/                            # Framework-level code
│   │   ├── constants/
│   │   │   ├── app_constants.dart
│   │   │   ├── api_constants.dart
│   │   │   └── asset_constants.dart
│   │   ├── theme/
│   │   │   ├── app_theme.dart
│   │   │   ├── app_colors.dart
│   │   │   ├── app_typography.dart
│   │   │   ├── app_spacing.dart
│   │   │   └── theme_provider.dart
│   │   ├── localization/
│   │   │   ├── app_localizations.dart
│   │   │   ├── locale_provider.dart
│   │   │   ├── l10n/
│   │   │   │   ├── app_ar.arb
│   │   │   │   └── app_en.arb
│   │   │   └── translation_helper.dart
│   │   ├── router/
│   │   │   ├── app_router.dart
│   │   │   ├── route_names.dart
│   │   │   └── route_guards.dart
│   │   ├── network/
│   │   │   ├── api_client.dart          # Dio HTTP client
│   │   │   ├── api_interceptors.dart    # JWT refresh, logging
│   │   │   ├── network_exceptions.dart
│   │   │   └── connectivity_service.dart
│   │   ├── storage/
│   │   │   ├── secure_storage.dart      # flutter_secure_storage
│   │   │   └── local_storage.dart       # shared_preferences
│   │   ├── providers/
│   │   │   └── providers.dart           # Global Riverpod providers
│   │   ├── extensions/
│   │   │   ├── context_extensions.dart
│   │   │   ├── string_extensions.dart
│   │   │   ├── date_extensions.dart
│   │   │   └── number_extensions.dart
│   │   ├── utils/
│   │   │   ├── date_formatter.dart
│   │   │   ├── currency_formatter.dart
│   │   │   ├── validators.dart
│   │   │   └── analytics_helper.dart
│   │   └── widgets/                     # Reusable UI components
│   │       ├── buttons/
│   │       │   ├── primary_button.dart
│   │       │   ├── secondary_button.dart
│   │       │   └── icon_button_widget.dart
│   │       ├── inputs/
│   │       │   ├── app_text_field.dart
│   │       │   ├── date_picker_field.dart
│   │       │   ├── passenger_counter.dart
│   │       │   └── search_field.dart
│   │       ├── cards/
│   │       │   ├── flight_card.dart
│   │       │   ├── hotel_card.dart
│   │       │   └── booking_card.dart
│   │       ├── loaders/
│   │       │   ├── shimmer_loader.dart
│   │       │   └── loading_overlay.dart
│   │       ├── empty_states/
│   │       │   └── empty_state_widget.dart
│   │       ├── error_widgets/
│   │       │   └── error_view.dart
│   │       ├── bottom_sheets/
│   │       │   ├── filter_bottom_sheet.dart
│   │       │   └── sort_bottom_sheet.dart
│   │       └── app_bar/
│   │           └── custom_app_bar.dart
│   │
│   └── features/                        # Feature modules
│       │
│       ├── onboarding/
│       │   ├── data/
│       │   ├── domain/
│       │   └── presentation/
│       │       ├── screens/
│       │       │   ├── splash_screen.dart
│       │       │   └── onboarding_screen.dart
│       │       └── widgets/
│       │
│       ├── auth/
│       │   ├── data/
│       │   │   ├── datasources/
│       │   │   │   └── auth_remote_datasource.dart
│       │   │   ├── models/
│       │   │   │   ├── user_model.dart
│       │   │   │   └── auth_token_model.dart
│       │   │   └── repositories/
│       │   │       └── auth_repository_impl.dart
│       │   ├── domain/
│       │   │   ├── entities/
│       │   │   │   └── user.dart
│       │   │   ├── repositories/
│       │   │   │   └── auth_repository.dart
│       │   │   └── usecases/
│       │   │       ├── login_usecase.dart
│       │   │       ├── register_usecase.dart
│       │   │       └── logout_usecase.dart
│       │   └── presentation/
│       │       ├── providers/
│       │       │   └── auth_provider.dart
│       │       └── screens/
│       │           ├── login_screen.dart
│       │           ├── register_screen.dart
│       │           └── otp_screen.dart
│       │
│       ├── home/
│       │   └── presentation/
│       │       ├── screens/
│       │       │   └── home_screen.dart
│       │       └── widgets/
│       │           ├── search_tabs_widget.dart
│       │           ├── deals_section.dart
│       │           ├── popular_destinations.dart
│       │           └── quick_actions.dart
│       │
│       ├── flights/
│       │   ├── data/
│       │   │   ├── datasources/
│       │   │   │   └── flight_remote_datasource.dart
│       │   │   ├── models/
│       │   │   │   ├── flight_search_model.dart
│       │   │   │   ├── flight_result_model.dart
│       │   │   │   └── flight_booking_model.dart
│       │   │   └── repositories/
│       │   │       └── flight_repository_impl.dart
│       │   ├── domain/
│       │   │   ├── entities/
│       │   │   │   ├── flight.dart
│       │   │   │   ├── flight_result.dart
│       │   │   │   └── flight_booking.dart
│       │   │   ├── repositories/
│       │   │   │   └── flight_repository.dart
│       │   │   └── usecases/
│       │   │       ├── search_flights_usecase.dart
│       │   │       └── book_flight_usecase.dart
│       │   └── presentation/
│       │       ├── providers/
│       │       │   ├── flight_search_provider.dart
│       │       │   ├── flight_results_provider.dart
│       │       │   └── flight_filter_provider.dart
│       │       ├── screens/
│       │       │   ├── flight_search_screen.dart
│       │       │   ├── flight_results_screen.dart
│       │       │   ├── flight_detail_screen.dart
│       │       │   ├── passenger_info_screen.dart
│       │       │   ├── seat_selection_screen.dart
│       │       │   └── flight_summary_screen.dart
│       │       └── widgets/
│       │           ├── flight_search_form.dart
│       │           ├── flight_result_card.dart
│       │           ├── flight_filter_panel.dart
│       │           ├── airline_logo.dart
│       │           ├── flight_segment_tile.dart
│       │           └── price_breakdown_sheet.dart
│       │
│       ├── hotels/
│       ├── packages/
│       ├── cars/
│       ├── transfers/
│       ├── activities/
│       ├── visa/
│       ├── insurance/
│       │
│       ├── bookings/
│       │   └── presentation/
│       │       ├── screens/
│       │       │   ├── bookings_screen.dart
│       │       │   └── booking_detail_screen.dart
│       │       └── widgets/
│       │           └── booking_status_chip.dart
│       │
│       ├── payment/
│       │   └── presentation/
│       │       ├── screens/
│       │       │   ├── payment_screen.dart
│       │       │   └── payment_result_screen.dart
│       │       └── widgets/
│       │           ├── payment_method_selector.dart
│       │           └── order_summary_card.dart
│       │
│       ├── wallet/
│       ├── profile/
│       ├── notifications/
│       ├── support/
│       ├── reviews/
│       │
│       └── ai/
│           └── presentation/
│               ├── screens/
│               │   ├── ai_chat_screen.dart
│               │   └── trip_planner_screen.dart
│               └── widgets/
│                   ├── chat_bubble.dart
│                   └── ai_suggestion_card.dart
│
├── assets/
│   ├── images/
│   ├── icons/
│   ├── animations/                      # Lottie files
│   └── fonts/
│
├── test/
│   ├── unit/
│   │   ├── domain/
│   │   └── presentation/
│   └── widget/
│
├── pubspec.yaml
├── analysis_options.yaml
├── dart_defines/
│   ├── dev.env
│   ├── staging.env
│   └── prod.env
└── README.md
```

---

## Key Dependencies (pubspec.yaml)

```yaml
name: saudi_travel_app
description: Saudi Travel Platform - AI Powered OTA
version: 1.0.0+1

environment:
  sdk: ">=3.3.0 <4.0.0"
  flutter: ">=3.19.0"

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter

  # State Management
  flutter_riverpod: ^2.5.1
  riverpod_annotation: ^2.3.5

  # Navigation
  go_router: ^13.2.0

  # Network
  dio: ^5.4.3
  retrofit: ^4.1.0

  # Storage
  flutter_secure_storage: ^9.0.0
  shared_preferences: ^2.2.3
  hive_flutter: ^1.1.0

  # UI
  flutter_svg: ^2.0.10
  cached_network_image: ^3.3.1
  lottie: ^3.1.0
  shimmer: ^3.0.0
  flutter_animate: ^4.5.0
  smooth_page_indicator: ^1.1.0
  intl: ^0.19.0

  # Firebase
  firebase_core: ^3.1.0
  firebase_auth: ^5.1.0
  firebase_analytics: ^11.1.0
  firebase_crashlytics: ^4.1.0
  firebase_messaging: ^15.0.0

  # Maps
  google_maps_flutter: ^2.6.0

  # Payments
  webview_flutter: ^4.7.0

  # Utilities
  freezed_annotation: ^2.4.1
  json_annotation: ^4.9.0
  equatable: ^2.0.5
  dartz: ^0.10.1
  logger: ^2.3.0
  package_info_plus: ^8.0.0
  url_launcher: ^6.3.0
  share_plus: ^9.0.0
  image_picker: ^1.1.0
  path_provider: ^2.1.3
  connectivity_plus: ^6.0.3
  local_auth: ^2.2.0        # Biometric auth

dev_dependencies:
  flutter_test:
    sdk: flutter
  build_runner: ^2.4.9
  freezed: ^2.5.2
  json_serializable: ^6.8.0
  retrofit_generator: ^8.1.0
  riverpod_generator: ^2.4.0
  flutter_lints: ^4.0.0
  mockito: ^5.4.4
  mocktail: ^1.0.3
```

---

## State Management Pattern (Riverpod)

```dart
// features/flights/presentation/providers/flight_search_provider.dart

@riverpod
class FlightSearchNotifier extends _$FlightSearchNotifier {
  @override
  FlightSearchState build() => FlightSearchState.initial();

  Future<void> search(FlightSearchParams params) async {
    state = state.copyWith(status: SearchStatus.loading);

    final result = await ref.read(flightRepositoryProvider)
        .searchFlights(params);

    result.fold(
      (failure) => state = state.copyWith(
        status: SearchStatus.error,
        error: failure.message,
      ),
      (results) => state = state.copyWith(
        status: SearchStatus.success,
        results: results,
        searchId: results.searchId,
      ),
    );
  }
}

// Usage in screen
class FlightResultsScreen extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(flightSearchNotifierProvider);

    return switch (state.status) {
      SearchStatus.loading => const FlightResultsSkeleton(),
      SearchStatus.error   => ErrorView(message: state.error!),
      SearchStatus.success => FlightResultsList(results: state.results),
      _                    => const SizedBox.shrink(),
    };
  }
}
```

---

## Navigation (GoRouter)

```dart
// core/router/app_router.dart

@riverpod
GoRouter appRouter(AppRouterRef ref) {
  final authState = ref.watch(authStateProvider);

  return GoRouter(
    initialLocation: RouteNames.home,
    redirect: (context, state) {
      final isLoggedIn = authState.isAuthenticated;
      final isAuthRoute = state.matchedLocation.startsWith('/auth');

      if (!isLoggedIn && !isAuthRoute) return RouteNames.login;
      if (isLoggedIn && isAuthRoute) return RouteNames.home;
      return null;
    },
    routes: [
      GoRoute(path: RouteNames.home, builder: (_, __) => const HomeScreen()),
      GoRoute(
        path: RouteNames.flightSearch,
        builder: (_, __) => const FlightSearchScreen(),
        routes: [
          GoRoute(
            path: 'results',
            builder: (_, state) => FlightResultsScreen(
              searchId: state.extra as String,
            ),
          ),
        ],
      ),
      GoRoute(path: RouteNames.login, builder: (_, __) => const LoginScreen()),
      // ... all routes
    ],
  );
}
```

---

## Theme Configuration

```dart
// core/theme/app_theme.dart

class AppTheme {
  static ThemeData light(Locale locale) {
    final isArabic = locale.languageCode == 'ar';

    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF1B6CA8),    // Brand blue
        brightness: Brightness.light,
      ),
      fontFamily: isArabic ? 'IBM Plex Arabic' : 'Inter',
      textTheme: _buildTextTheme(isArabic),
      cardTheme: _buildCardTheme(),
      inputDecorationTheme: _buildInputTheme(),
      elevatedButtonTheme: _buildButtonTheme(),
    );
  }

  static ThemeData dark(Locale locale) {
    final isArabic = locale.languageCode == 'ar';
    return light(locale).copyWith(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(
        seedColor: const Color(0xFF1B6CA8),
        brightness: Brightness.dark,
      ),
    );
  }
}
```

---

## RTL/LTR Handling

```dart
// Directionality is handled automatically by Flutter
// when locale is set to Arabic (RTL)

// For manual override in specific widgets:
Directionality(
  textDirection: context.isArabic ? TextDirection.rtl : TextDirection.ltr,
  child: YourWidget(),
)

// Extension
extension BuildContextX on BuildContext {
  bool get isArabic => Localizations.localeOf(this).languageCode == 'ar';
  TextDirection get textDirection =>
    isArabic ? TextDirection.rtl : TextDirection.ltr;
}
```
